const a={"cta.contact":"CONTACT KOLLAB","cta.apply":"APPLY NOW","nav.about":"About","nav.platform":"Platform","nav.brands":"Brands","nav.contact":"Contact","nav.faq":"FAQ"};export{a as default};
