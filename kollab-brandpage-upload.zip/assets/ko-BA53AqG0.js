const a={"cta.contact":"KOLLAB 문의","cta.apply":"지금 신청","nav.about":"어바웃","nav.platform":"플랫폼","nav.brands":"브랜즈","nav.contact":"컨택트","nav.faq":"FAQ"};export{a as default};
